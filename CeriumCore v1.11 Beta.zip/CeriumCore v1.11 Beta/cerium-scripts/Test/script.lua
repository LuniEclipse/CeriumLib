-- Тестовый плагин для проверки возможностей
local BASE_DIR = '/storage/emulated/0/Android/data/com.sandboxol.blockymods/files/Download/SandboxOL/BlockManv2/map_temp/g20151633/'

-- 1. Проверяем запись файлов
local test_file = BASE_DIR .. "cerium-scripts/test_result.txt"
local f = io.open(test_file, "w")
if f then
    f:write("Плагин успешно запущен в: " .. os.date("%H:%M:%S") .. "\n")
    f:write("Привет от CeriumCore Plugin System!\n")
    f:close()
    print("TEST: File written successfully!")
else
    print("TEST: Failed to write file!")
end

-- 2. Пробуем изменить какую-то переменную игры
-- Например, выведем версию движка в лог
if Engine and Engine.getEngineVersion then
    print("TEST: Engine Version is " .. Engine.getEngineVersion())
end

-- 3. Проверяем, работает ли cjson
local ok, cjson = pcall(require, 'cjson')
if ok and cjson then
    local data = { status = "ok", message = "Plugin system works!" }
    local json_str = cjson.encode(data)
    print("TEST: JSON encode works: " .. json_str)
end