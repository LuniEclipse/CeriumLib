-- script.lua
return function(api)
    -- Теперь мы используем api.showToast вместо просто showToast
    api.log("Скрипт запущен!")
    api.showToast("Ура! Скрипты работают без глобалов!")
    
    -- Пример с файлами
    local path = api.BASE_DIR .. "test.txt"
    local f = io.open(path, "w")
    f:write("Hello from script!")
    f:close()
end