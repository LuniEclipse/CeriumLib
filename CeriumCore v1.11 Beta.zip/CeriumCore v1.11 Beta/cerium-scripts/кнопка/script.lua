local btn = UI:CreateGUIWidget(Enum.WidgetType.Button)
btn:setText("CLICK ME")
btn:setPosition(UDim2.new(0.4, 0, 0.4, 0))
btn:setSize(UDim2.new(0.2, 0, 0, 60))
UI.root:addChild(btn)

btn.onMouseClick = function()
    print("Button clicked!")
end