-- Плагин для добавления блоков в креатив GameRoom
local app_res_root = '/data/user/0/com.sandboxol.blockymods/app_resources/'
local lfs = require('lfs')

-- Создаем папки, если их нет
pcall(function() lfs.mkdir(app_res_root .. 'Media') end)
pcall(function() lfs.mkdir(app_res_root .. 'Media/Scripts') end)
pcall(function() lfs.mkdir(app_res_root .. 'Media/Scripts/Game') end)
pcall(function() lfs.mkdir(app_res_root .. 'Media/Scripts/Game/g1100') end)
pcall(function() lfs.mkdir(app_res_root .. 'Media/Scripts/Game/g1100/setting') end)

local csv_path = app_res_root .. 'Media/Scripts/Game/g1100/setting/CreativeBlock.csv'
local f = io.open(csv_path, 'w')
if f then
    f:write("ItemId\tsubItemId\n")
    -- Добавляем базовые блоки
    for i = 1, 174 do
        f:write(i .. "\t0\n")
    end
    -- Добавляем цветную шерсть (ID 35, мета от 0 до 15)
    for meta = 0, 15 do
        f:write("35\t" .. meta .. "\n")
    end
    -- Добавляем бетон (ID 251, мета от 0 до 15)
    for meta = 0, 15 do
        f:write("251\t" .. meta .. "\n")
    end
    -- И другие блоки, которые ты хочешь...
    
    f:close()
    print("CREATIVE: CreativeBlock.csv generated successfully!")
else
    print("CREATIVE: Failed to write file.")
end